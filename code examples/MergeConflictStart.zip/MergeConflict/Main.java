public class Main {

    public static void main(String[] args) {

        Hotel hotel = new Hotel(5);
        System.out.println(hotel.toString());

        Guest guest1 = new Guest("Adam", "today", "Czech" );
        Guest guest2 = new Guest("Berta", "today", "Scot" );
        Guest guest3 = new Guest("Orel", "yestarday", "Nor" );

        hotel.checkIn(guest1);
        hotel.checkIn(guest2);
        System.out.println(hotel.toString());

        hotel.checkOut(guest2);
        System.out.println(hotel.toString());
    }
}
