import java.util.ArrayList;

public class Hotel
{
    private int capacity;

    String hotelName;

    private ArrayList<Guest> guests;

    public Hotel(int capacity, String hotelName)
    {
        this.capacity = capacity;
        this.hotelName = hotelName;
        guests = new ArrayList<Guest>();
    }

    public int getCapacity()
    {
        return capacity;
    }

    public void checkIn(Guest guest)
    {
        guests.add(guest);
    }

    public void checkOut(Guest guest)
    {
        guests.remove(guest);
    }

    public int getVacancy()
    {
        return capacity - guests.size();
    }

    @Override
    public String toString()
    {
        return "Hotel{" +
		"hotelName=" + hotelName +
                "capacity=" + capacity +
                ", guests=" + guests.size() + " " +guests.toString()+
                '}';
    }
}
