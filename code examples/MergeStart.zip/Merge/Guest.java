public class Guest
{
    private String name;
    private String arrival;
    private String departure;
    private String nationality;
    private int age;

    public Guest()
    {
    }

    public Guest(String name, String arrival, String nationality, int age)
    {
        this.name = name;
        this.arrival = arrival;
        this.nationality = nationality;
        this.age = age;
    }

    public String getName()
    {
        return name;
    }

    public String getArrival()
    {
        return arrival;
    }

    public String getDeparture()
    {
        return departure;
    }

    public void setDeparture(String departure)
    {
        this.departure = departure;
    }

    public String getNationality()
    {
        return nationality;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @java.lang.Override
    public java.lang.String toString() {
        return "Guest{" +
                "name='" + name + '\'' +
                ", arrival='" + arrival + '\'' +
                ", departure='" + departure + '\'' +
                ", nationality='" + nationality + '\'' +
                ", age=" + age +
                '}';
    }
}
